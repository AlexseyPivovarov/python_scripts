year = int(input("Какой сейчас текущий год?\n"))
age = int(input("Сколько Вам полных лет?\n"))
print("Вы родились в {} году".format(year - age))
print("Вам осталось до пенсии {} лет".format(65 - age))
